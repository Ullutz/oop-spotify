package app.Commands;

public class ShowPrefGenreCommand {
}
